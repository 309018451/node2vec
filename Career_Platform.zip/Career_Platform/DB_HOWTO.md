Database How-To
================

Here are steps to setup a local MySQL database to be used in this project 

### Install MySQL 

Download the installer and follow proper installation guide. For Ubuntu 16.04+,

    sudo apt-get install mysql-server
    
    mysql_secure_installation


After installation, make sure the MySQL service is started. 

    sudo systemctl start mysql

For common MySQL usage, see [https://github.com/yangli1-stanford/careerDataAnnotator/blob/liu1/MySQL-Example.ipynb].

### Create a database 

On a terminal, start mysql as root

    mysql -u root
    
Inside the SQL terminal, create a new database named `CAREER`

    mysql> create database CAREER
     
### Add initial data to the database

You can either add content to the database from raw resume files using 
our parser code, or import an existing database dump file.  

#### Option 1: add content from raw data files

Sample code for creating and populating tables used in this project 
can be found in `demo/db_init.py`. (Make sure to read the comments)  
To run, go to the project root directory,   

    python demo/db_init.py


#### Option 2: insert from sql dump file

** Warning: table formats in the dump file may be out-of-date. ** 


A test dump file for resume data is located at `data/user_data.sql` 


    mysql -u root -p CAREER < data/user_data.sql

The table containing all label-keyword mappings for rule-based classification 
is located at `data/label_rules.sql` 

 
To export any table in the CAREER database to an sql file:

    mysqldump -u root -p CAREER {table_name} > data/{table_name}.sql

### Current Database Schema

Currently our database has three main tables:

#### Description for table `user_data`

| Field 	| Type 	| Meaning 	| Example 	|
|------------	|-----------	|-----------------------------	|-------------------------------------------------------	|
| uid 	| int 	| 用户编号 (starting from 0) 	| 167   |
| rid 	| int 	| 经历编号 (starting from 0) 	| 3    	|
| time 	| char(32) 	| 时间段  	| 2016.12—2019.02 	|
| raw  	| char(128) 	| 原始句子 	| 2016.12—2019.02  深圳市龙岗区安监局局长监察大队大队长 	|
| seg 	| char(128) 	| 分词预测（空格隔开）  	| 深圳市 龙岗区 安监局 局长 监察大队 大队长 	|
| loc 	| char(32) 	| 地点 （未使用） 	| 深圳市龙岗区 	|
| occ 	| char(32) 	| 职位 （未使用） 	| 大队长 	|
| label 	| char(128) 	| 标签 （半角逗号隔开）  	| 政法,基层工作 	|
| mseg 	| char(128) 	| 手工分词 （空格隔开） 	| 深圳市 龙岗区 安监局 局长监察大队 大队长 	|
| mlabel 	| char(128) 	| 手工标签 （半角逗号隔开） 	| 政法 	|
| batch 	| int 	| 标记批次（未使用）默认值为0 	| 1         	|
| mtimestamp 	| char(32) 	| 标签时间  	| Fri May 15 01:02:45 CST 2020 	|
 

#### Description for table `label_rules`

| Field    | Type      | Meaning | Example |
|----------|-----------|---------|---------|
| label    | char(128) | 标签     | 金融     |
| keywords | char(128) | 关键字    | 基金,投资,贸易       |

#### Description for table `words`

| Field    | Type      | Meaning | Example |
|----------|-----------|---------|---------|
| wid    | int | 标签     | ID   | 0 |
| words | varchar(255) | 词语 (unique index)  | 处长      |
| part | varchar(255)  | 词性 |  nr |
| frequency | int | 频次   | 1    |

