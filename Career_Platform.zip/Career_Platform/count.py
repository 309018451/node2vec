# -*- coding: utf-8 -*-
"""
Created on Wed Jun  3 20:57:57 2020

@author: ASUS
"""
import os
parent_path=os.getcwd()
parents = os.listdir(parent_path)
print(parents)
# 
#print(os.path.abspath('.'))#获得当前工作目录
# 
#print(os.path.abspath('..'))#获得当前工作目录的父目录
# 
#print(os.path.abspath(os.curdir))#获得当前工作目录