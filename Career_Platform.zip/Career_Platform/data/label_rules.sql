-- MySQL dump 10.13  Distrib 8.0.19, for osx10.15 (x86_64)
--
-- Host: localhost    Database: CAREER
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `label_rules`
--

DROP TABLE IF EXISTS `label_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `label_rules` (
  `label` char(128) DEFAULT NULL,
  `keywords` char(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label_rules`
--

LOCK TABLES `label_rules` WRITE;
/*!40000 ALTER TABLE `label_rules` DISABLE KEYS */;
INSERT INTO `label_rules` VALUES ('纪检监察','纪委,监察,稽查'),('党的建设','党校,党委,中央'),('政法','常委,人大,政府,政法'),('公安','公安,缉毒,派出所'),('法律','司法,法律,立法'),('外事和港澳工作','港,澳,外交'),('经济','外贸,贸易,经济'),('金融','基金,投资,贸易'),('产业','规划,产品'),('科技','电子,计算机,科技'),('企业管理','企业管理,公司管理'),('财务','财政,财务,预算'),('工程建设','冶金,铁路,建设'),('国土规划','国土,地产,规划'),('交通运输','交通,运政,物流'),('生态环境','工业废物,环境,环保,生态,污染'),('水务','水利,水务'),('教育','大学,学院,专业'),('卫生','细菌,卫生'),('信息技术','技术,信息,电子'),('应急处突','应急,处突'),('群团工作','群团,工作'),('基层治理','基层,治理'),('政策研究','政策,法规,教研'),('单位一把手经历','局长,市长,省长,长'),('街道书记经历','街道,书记'),('基层经历','基层,下乡,插队'),('部队经历','司令,部队,军'),('援派和扶贫工作经历','扶贫,支援'),('留学经历','美国,英国,瑞士'),('新担当新作为先进典型','典型'),('十佳街道书记','十佳街道书记'),('纪检监察','纪委,监察,稽查'),('党的建设','党校,党委,中央'),('政法','常委,人大,政府,政法'),('公安','公安,缉毒,派出所'),('法律','司法,法律,立法'),('外事和港澳工作','港,澳,外交'),('经济','外贸,贸易,经济'),('金融','基金,投资,贸易'),('产业','规划,产品'),('科技','电子,计算机,科技'),('企业管理','企业管理,公司管理'),('财务','财政,财务,预算'),('工程建设','冶金,铁路,建设'),('国土规划','国土,地产,规划'),('交通运输','交通,运政,物流'),('生态环境','工业废物,环境,环保,生态,污染'),('水务','水利,水务'),('教育','大学,学院,专业'),('卫生','细菌,卫生'),('信息技术','技术,信息,电子'),('应急处突','应急,处突'),('群团工作','群团,工作'),('基层治理','基层,治理'),('政策研究','政策,法规,教研'),('单位一把手经历','局长,市长,省长,长'),('街道书记经历','街道,书记'),('基层经历','基层,下乡,插队'),('部队经历','司令,部队,军'),('援派和扶贫工作经历','扶贫,支援'),('留学经历','美国,英国,瑞士'),('新担当新作为先进典型','典型'),('十佳街道书记','十佳街道书记');
/*!40000 ALTER TABLE `label_rules` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-31  1:35:33
