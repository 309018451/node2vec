import context
from Career_Platform.parser.catalog import ResumeFileIO
from Career_Platform.parser.tokenizer import JiebaTokenizer 
from Career_Platform.parser.label_classifier import ManualLabelClassifier
from Career_Platform.parser.db_interface import DBInterface

'''
initialize database table 'user_data' with parsed data

'''


if __name__=='__main__':
    # initilize resume catalog
    catalog = ResumeFileIO('data/out_ori.txt')
    
    # tokenize all resume entries
    tokenizer = JiebaTokenizer()
    catalog.add_tokenizer(tokenizer)
    catalog.parse_catalog() 
    
    
    
    # set db connection info  
    db_options = {'host':'localhost', 'user': 'root','password':'',
                 'port':3306,'database':'CAREER'}
    
    db = DBInterface(db_options) 
    
    # initialize user_data table
    #db.initialize_catalog_db() 
    
    # initialize label_rules table
    #db.initialize_rules_db() 
    #db.write_rule_dict1(dict1={}): 
    
    
    # classify all resume entries
    cla = ManualLabelClassifier(rules  = db.db_2_rule_dict()) 
    
    catalog.add_classifier(cla)
    catalog.classify_all()
    
    
    # rewrite catalog content to database with parsed values
    db.write_catalog(catalog,clear_table=True)
     
   
    
    