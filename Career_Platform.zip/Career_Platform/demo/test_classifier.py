#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May  1 18:46:25 2020

@author: Career_Platform


compare different classifiers on test data

A test for classifier
"""
import context
import pickle
from Career_Platform.parser.catalog import Catalog,WorkExperience
from Career_Platform.parser.db_interface import DBInterface
from Career_Platform.parser.label_classifier import ManualLabelClassifier,OneVsRestSGDClassifier
from Career_Platform.parser.tokenizer import JiebaTokenizer 
import numpy as np

 
            
def test_clustering(db,train_fasttext=False, train_clf=False,write_dataset=False):
    import sys
    origin = sys.stdout
    f = open('file.txt', 'w')
    sys.stdout = f
    import numpy as np
    from sklearn.cluster import SpectralClustering
    from gensim.models import FastText
    catalog = Catalog()
    db.read_catalog(catalog) 
    
    train_labels = catalog.get_all_labels()   
    idx = [ i for i in range(len(train_labels)) if train_labels[i].strip() !='undefined' ]
    print('# of training data',len(idx))
          
    train_sentences = catalog.get_all_parsed()
    train_sentences = [ train_sentences[i] for i in  idx] 
    train_labels = [train_labels[i] for i in idx]
#    print(train_sentences[0:20])
#    print(train_labels[0:20])
    
    # build classifier trained on the parsed sentences
    cla = OneVsRestSGDClassifier() 
        
    X,Y=cla.train(train_sentences, train_labels)  
    cla.save_clf('../data/onevsrest_sgd_model.pkl')
    train_sentences=train_sentences[0:600]
    Y=Y[0:200]
    model = FastText(min_count=1)
    model.build_vocab(train_sentences)
    model.train(train_sentences, total_examples=model.corpus_count, epochs=model.epochs)
    Y=Y.tolist()
    for value in range(1,5):
        value=value/10
        print('----------------------------------------------------')
        print('当前设定的阈值为 '+str(value))
        for index,thing1 in enumerate(train_sentences):
            print(thing1)
            print('before top k ')
            B=['纪检监察', '党的建设', '政法', '公安', '法律', '外事和港澳工作', '经济', '金融', '产业', '科技', '企业管理', '财务', '工程建设', '国土规划', '交通运输', '生态环境', '水务', '教育', '卫生', '信息技术', '应急处突', '群团工作', '基层治理', '政策研究', '单位一把手经历', '街道书记经历', '基层经历', '部队经历', '援派和扶贫工作经历', '留学经历', '新担当新作为先进典型', '十佳街道书记', '纪检监察', '党的建设', '政法', '公安', '法律', '外事和港澳工作', '经济', '金融', '产业', '科技', '企业管理', '财务', '工程建设', '国土规划', '交通运输', '生态环境', '水务', '教育', '卫生', '信息技术', '应急处突', '群团工作', '基层治理', '政策研究', '单位一把手经历', '街道书记经历', '基层经历', '部队经历', '援派和扶贫工作经历', '留学经历', '新担当新作为先进典型', '十佳街道书记']
            A=[]
            for index1,thing in enumerate(Y[index]):
                if(thing==1):
                    A.append(B[index1])
            print(A)
            print('after top k ')
            Y=topk(model,thing1,10,train_sentences,Y,value)
            A=[]
            for index1,thing in enumerate(Y[index]):
                if(thing==1):
                    A.append(B[index1])
            print(A)
        print('----------------------------------------------------')
    sys.stdout = origin
    f.close()					#输出文件       
def topk(model,x,k,sentences,labels,threshold):
    index_=0
    distance=[]
    for index,thing in enumerate(sentences):
        if(x==thing):
            index_=index       
        else:
            distance.append(model.wv.wmdistance(x,thing))
    del labels[index_]
    X=labels
    Y=distance
    Z = [x for _,x in sorted(zip(Y,X))]
#    print(distance)
    res=[sum(i)/len(i) for i in zip(*Z[0:10])]
#    print(res)
    res=[1 if thing>threshold else 0 for thing in res]
    labels[index_]=res
    return labels
    
if __name__=='__main__':
    
    db_options = {'host':'localhost', 'user': 'root','password':'',
                 'port':3306,'database':'CAREER'}
    
    db = DBInterface(db_options)
#    db.initialize_rules_db()
    
    # train classification models from main dataset
#    cla_manual = testManual(db)
#    cla_onevsrest = testOneVsRestSGD(db)
    test_clustering(db)
