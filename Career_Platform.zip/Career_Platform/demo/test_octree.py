import context
from Career_Platform.octree.OCtree import CTree
from Career_Platform.parser.catalog import ResumeFileIO
from Career_Platform.parser.tokenizer import JiebaTokenizer 

'''
-load raw file, perform processing and extract sequences
 
-for each experience, run jieba to perform initial parsing

-call oc tree to generate sequences

'''

if __name__=='__main__':
    # initilize resume catalog
    catalog = ResumeFileIO('data/out_ori.txt')
    
    # tokenize all resume entries
    tokenizer = JiebaTokenizer()
    catalog.add_tokenizer(tokenizer)
    catalog.parse_catalog()
    
    
    catalog.print( max_n=20) 
    input('press any key to continue...')
    
    # generate OC tree from tokenized entries
    tree = CTree()
    tree.build_tree(catalog.get_all_parsed())
    tree.compress_tree()
    tree.show(data_property="name")
    
    