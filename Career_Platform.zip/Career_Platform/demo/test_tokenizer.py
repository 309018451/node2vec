#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May  1 18:46:25 2020

@author: yang


test tokenizer update functionality

A test for classifier
"""
import context
from Career_Platform.parser.tokenizer import JiebaTokenizer 
 

if __name__=='__main__':
    
    
    tokenizer = JiebaTokenizer()
    
    
    # get test data  
    testdata= [#'42集团军炮兵第一师特务连指导员',
            '深圳市政府应急管理办公室预案综合处调研员',
               '武警学院科研部科研所专职科研工作所所长','深圳报业集团人力资源中心主任',
               '深圳报业集团人力资源部主任']

    # get parsing result
    segs= tokenizer.parse_strings(testdata)
    
    # get manual segmentations
    list_msegs= [ #'42集团军,炮兵第一师,特务连,指导员',
                '深圳市,政府应急管理办公室,预案综合处,调研员',
                '武警学院,科研部,科研所,专职科研工作所,所长',
                '深圳报业集团,人力资源中心,主任',
               '深圳报业集团,人力资源部,主任'] 
    
    new_words = tokenizer.update_dict_db(list_msegs)
    print('new words:',new_words)
    
    # redo segmentation
    
    segs_updated= tokenizer.parse_strings(testdata) 
    
    
    for i   in  range(len( testdata)):
     
        print('\nQuery:',testdata[i])
        print('before :' ,segs[i]) 
        print('after :',segs_updated[i])  
        print('ground truth', list_msegs[i])
        

