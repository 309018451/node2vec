#!/bin/bash
# deployment script
# copy the libary files to target path 


function usage {
    echo "./deploy.sh <install_path> "    
}

if [ -z "$1" ];    then
        usage
        exit 0
fi

INSTALL_PATH=$1


###########################################
# list of files in the module
###########################################

FILES="__init__.py \
parser/__init__.py \
parser/catalog.py \
parser/database.py \
parser/db_interface.py \
parser/label_classifier.py \
parser/tokenizer.py \
octree/__init__.py \
octree/OCtree.py \
octree/OCnode.py \
"

DATA="data/labels.txt \
data/userdict.txt \
data/fasttext_model \
data/fasttext_model.wv.vectors_ngrams.npy \
data/fasttext_model.trainables.vectors_ngrams_lockf.npy \
data/onevsrest_sgd_model.pkl\
"

CP="Career_Platform"

###########################################
# create module directories
###########################################

mkdir -p ${INSTALL_PATH}/$CP/parser ${INSTALL_PATH}/$CP/octree \
${INSTALL_PATH}/$CP/data

###########################################
# add files
###########################################

for FILE in $(echo $FILES | tr " " "\n")
do
    cp -v $FILE ${INSTALL_PATH}/$CP/$FILE
done

