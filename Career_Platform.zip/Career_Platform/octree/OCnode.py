# -*- coding: utf-8 -*-
"""
Created on Fri May  1 23:24:12 2020

@author: ASUS
"""

class CNode(dict): 
    def __init__(self, id,name=None,count=None,positions=None): 
        self.id = id # Represents a different ID, each node has a different ID eg:0,1,2,3
        self.name = name  #eg: ”深圳市”“南山区“ ”南山街道”       
        super().__init__(self,name=name) # attribute in json export
        self.positions = positions  #position information, eg:”处长”“局长“
        self.count = count # Represents if the node is the last node eg:  ”深圳市 南山区 南山街道 队长”   “南山街道 count=1  南山区count=0
        super().__init__(self,count=count)
        self.txt_info=[]

    def get_prefix(self): 
        pass  
    
    def setname(self,name):
        self.name=name
    def count_plus(self):
        self.count=self.count+1
    def set_count(self,count):
        self.count=count
    def append_txt_info(self,txt):
        self.txt_info.append(txt)