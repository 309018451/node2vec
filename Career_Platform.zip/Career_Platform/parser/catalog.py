
import re


class Experience:
    def __init__(self,text, time=None, loc=None, org=None,seg=None,labels=None):
        self.text=text
        self.time=time   
        self.organization=org
        self.location=loc
        self.segmented = seg # segmented string
        self.labels = labels # list of labels 
        
class WorkExperience(Experience):
    def __init__(self, text, time=None, loc=None, org=None,seg=None,
                 labels=None, pos=None):
        Experience.__init__(self,text,time,loc,org,seg,labels)
        self.position = pos
        
class Person:
    def __init__(self,name):
        self.name = name
        self.work_exp = []
        
    
class Catalog:
    def __init__(self):
        self.users= []
        self.tokenizer = None
        self.classifier = None
        
    def clear(self):
        self.users = []
        
    def print(self, raw=False,max_n = 2000):
        ct = 0
        for u in self.users:
            print('name:', u.name )
            for i,exp in enumerate(u.work_exp):
                if ct >= max_n:
                    return
                if raw:
                    print(i,exp.text)
                else:
                    print(i,exp.time,'parsed:',exp.segmented,
                          'labels:',exp.labels, 'loc:',exp.location,
                          'pos:',exp.position)
                ct+=1 
                
                
    def get_all_parsed(self):
        result=[]
        for u in self.users:
            for exp in u.work_exp:
                result.append(exp.segmented)
        return result
    
    def get_all_labels(self):
        result=[]
        for u in self.users:
            for exp in u.work_exp:
                result.append(exp.labels)
        return result
        
    def add_tokenizer(self, tokenizer):
        self.tokenizer = tokenizer
        
        
    def parse_catalog(self):  
        if not self.tokenizer:
            print('Error: Please add a tokenizer first!')
            return
        for user in self.users:
            for exp in user.work_exp:
                result = self.tokenizer.parse_strings([exp.text],simple=False)[0]
                if len(result)<=3:
                    print('[Error] fail to parse', exp.text)
                    continue
                result = result[3:]
                exp.location=''
                org_pos = []
                exp.segmented=' '.join([word for  word,flag in result ])
                for word,flag in result:
                    if flag == 'ns' or flag == 'LOC':
                        exp.location += word 
                    
                    if flag != 'm' and flag != 'x':
                        org_pos.append( (word,flag) ) 
                exp.position =   org_pos[-1][0]
                exp.organization=''.join( [w for w,f in org_pos[:-1]])
            
    def add_classifier(self,cla):
        self.classifier = cla
        
    def classify_all(self):
        if not self.classifier:
            print('Error: Please add a label classifier first!')
        for user in self.users:
            for exp in user.work_exp:
                print(exp.text)
                if exp.organization and exp.position:
                    exp.labels  = self.classifier.classify(exp.organization+exp.position)
        
        
        
class ResumeFileIO(Catalog):
    def __init__(self,filename):
        Catalog.__init__(self)
        self.filename = filename
        self.read_resume_txt()
        #self.print(raw=True)
        
    def read_resume_txt(self):
        print('reading from ',self.filename)
         
        newPerson = None
        newEntry = None
        with open(self.filename, encoding='utf-8') as f:
            buffer = []
            for line in f:   
                line= line.strip()
                line= self.remove_parentheses(line)
                line= self.remove_text_after_comma(line)
                line = re.sub("—今","—9999.99",line)
                #if line[0] is '-':
                #    continue
                m_head = re.match("([0-9]+).xls",line)
                m_entry = re.match("(\d{4}.\d{1,2}?—\d{4}.\d{1,2})\s*(.+)",line)
                m_entry_cont = re.match("^(?![-|—]).*",line)
                if m_head :
                    if newPerson:
                        if newEntry:
                            newPerson.work_exp.append(newEntry) 
                            newEntry=None
                        self.users.append(newPerson)
                    newPerson = Person(m_head.group(1))
                elif m_entry:
                    if newEntry and len(newEntry.text)>=20 :
                        # only add entries at least 20 characters long
                        newPerson.work_exp.append(newEntry) 
                    time = m_entry.group(1)
                    print('tim:',time)
                    text = m_entry.group(2)
                    print('date',time,'text',text)
                    newEntry = WorkExperience(line,time=time )
                elif m_entry_cont:
                    newEntry.text +=line
               
 
    def remove_parentheses(self,line):
         return re.sub("\(.*\)","",line)
     
    def remove_text_after_comma(self,line):
        return re.sub("[、|，|；|,|;].*$","",line)
 
 
    
