#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May  5 00:05:45 2020

@author: yang
"""
import pymysql
from Career_Platform.parser.catalog import Person,WorkExperience


class DBInterface:
    """ a utility class that provide an interface with database """
    def __init__(self,db_options): 
        try:
            self.mysql = pymysql.connect(host=db_options['host'], 
                                      user=db_options['user'], 
                                      password=db_options['password'], 
                                      port=db_options['port'],
                                      database=db_options['database'])
            self.cursor = self.mysql.cursor()
        except Exception as e:
            print('Error connecting to database:{0}'.format(e)) 
    

#####################################################
# RESUME CATALOG
#####################################################
    def initialize_catalog_db(self):
        sql = """
        CREATE TABLE user_data (
        uid INT,
        rid INT,
        time CHAR(32),
        raw CHAR(128),
        seg CHAR(128),
        loc CHAR(32),
        occ CHAR(32),
        label CHAR(128),
        mseg CHAR(128),
        mlabel CHAR(128),
        batch INT,
        mtimestamp CHAR(32)
        );
        """
        self.cursor.execute(sql)
        
        self.mysql.commit()
        res=self.cursor.execute('desc user_data;')
        print(res)
        
    def read_catalog(self,catalog, append=True):
        """
        load entries from database and store in catalog
        """
        if not append:
            catalog.clear()  
         
        sql = "SELECT DISTINCT uid FROM user_data;"
        self.cursor.execute(sql)
        uids =  self.cursor.fetchall()  
        catalog.users= [Person(name=i) for i in uids ]
        for i,uid in enumerate(uids):
            sql = "SELECT * FROM user_data WHERE uid = %s" % uid 
            self.cursor.execute(sql)
            data = self.cursor.fetchall()
            for j,entry in enumerate(data):
                seg = entry[4] if entry[6]=='' else entry[6]
                labels = entry[5] if entry[7]=='' else entry[7]
                e = WorkExperience(text=entry[3],time=entry[2],seg=seg,
                                   labels=labels  )
                catalog.users[i].work_exp.append(e) 
        
        
    def write_catalog(self, catalog, clear_table=False):
        """
        insert all resume entries info into database. 
        
        Note: loc (location) and occ (occupation) are not set as the current 
            parsing results are not accurate enough
        
        Parameters
        ----------
        catalog: Catalog
          container for the resume data
          
        """ 
        if clear_table:
            # remove all entries in user_data
            sql = '''truncate table user_data'''
            self.cursor.execute(sql)
            self.mysql.commit()
        
        # writing content
        dataset=[]
        for uid,u in enumerate(catalog.users): 
            for rid,exp in enumerate(u.work_exp): 
                if exp:
                    labels = ''
                    seg =''
                    if exp.labels:
                        labels = ','.join(exp.labels)
                    if exp.segmented:
                        seg = exp.segmented
                    
                    row = (uid,rid,exp.time,exp.text,seg,
                            '','',
                              labels ,
                            '','',0,'')   
                    print(row)
                    dataset.append(row)
                    
        sql = '''insert into user_data values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);'''
        res = self.cursor.executemany(sql,dataset) 
        print(res)
        self.mysql.commit()  
        
    def set_user_data_by_id(self,uid,rid,colname,value):
        
        #sql = '''UPDATE user_data SET %s=%s WHERE uid=%s and rid=%s'''
        sql = '''UPDATE user_data SET {}='{}' WHERE uid={} and rid={}'''.format(colname,value,uid,rid)
        
        print(sql)
        self.cursor.execute(sql )
        self.mysql.commit()
        
#####################################################
# Manually Defined Label Rules
#####################################################

    def initialize_rules_db(self):
        sql = """
        CREATE TABLE label_rules (
        label CHAR(128),
        keywords CHAR(128)
        );
        """
        self.cursor.execute(sql)
        self.mysql.commit()
        res=self.cursor.execute('desc label_rules;')
        print(res)

    def write_rule_dict1(self,dict1): 
        if(dict1=={}):
            dict1['纪检监察']=['纪委','监察','稽查']
            dict1['党的建设']=['党校','党委','中央']
            dict1['政法']=['常委','人大','政府','政法']
            dict1['公安']=['公安','缉毒','派出所']
            dict1['法律']=['司法','法律','立法']
            dict1['外事和港澳工作']=['港','澳','外交']
            dict1['经济']=['外贸','贸易','经济']
            dict1['金融']=['基金','投资','贸易']
            dict1['产业']=['规划','产品']
            dict1['科技']=['电子','计算机','科技']
            dict1['企业管理']=['企业管理','公司管理']
            dict1['财务']=['财政','财务','预算']
            dict1['工程建设']=['冶金','铁路','建设']
            dict1['国土规划']=['国土','地产','规划']
            dict1['交通运输']=['交通','运政','物流']
            dict1['生态环境']=['工业废物','环境','环保','生态','污染']
            dict1['水务']=['水利','水务']
            dict1['教育']=['大学','学院','专业']
            dict1['卫生']=['细菌','卫生']
            dict1['信息技术']=['技术','信息','电子']
            dict1['应急处突']=['应急','处突']
            dict1['群团工作']=['群团','工作']
            dict1['基层治理']=['基层','治理']
            dict1['政策研究']=['政策','法规','教研']
            dict1['单位一把手经历']=['局长','市长','省长','长']
            dict1['街道书记经历']=['街道','书记']
            dict1['基层经历']=['基层','下乡','插队']
            dict1['部队经历']=['司令','部队','军']
            dict1['援派和扶贫工作经历']=['扶贫','支援']
            dict1['留学经历']=['美国','英国','瑞士']
            dict1['新担当新作为先进典型']=['典型']
            dict1['十佳街道书记']=['十佳街道书记']
        dataset=[]
        for w,v in dict1.items():
            dataset.append((w,','.join(v)))
        print(dataset[0])
        sql = '''insert into label_rules values(%s,%s);'''
        res = self.cursor.executemany(sql,dataset) 
        print(res)
        self.mysql.commit()    
        
    
    # =========================================================================
    #add one word into tabel where key=key
    # ex:['留学经历']=['美国','英国','瑞士'] 
    #db.save_db('留学经历','十佳街道书记')
    #['留学经历']=['美国','英国','瑞士','十佳街道书记'] 
    # =========================================================================
    def add_rule_to_db(self,key,word):
        #cursor = self.mysql.cursor()
        sql = "SELECT keywords FROM user_data WHERE label = %s;"
        self.cursor.execute(sql,key)
        data = self.cursor.fetchone()
        data_list=data[0].split(',')
        data_list.append(word)
        data_str=','.join(set(data_list))
        sql = "update label_rules set keywords = %s WHERE label=%s;"
        self.cursor.execute(sql,[data_str,key])
        self.mysql.commit()

    # =========================================================================
    # Get dict{key,word} from db
    # =========================================================================
    def db_2_rule_dict(self):
        #cursor = self.mysql.cursor()
        new_dict={}
        sql = "SELECT label,keywords FROM label_rules;"
        self.cursor.execute(sql)
        data = self.cursor.fetchall()
        for thing in data:
            new_dict[thing[0]]=thing[1].split(',')
        return new_dict

    
###########################################################
# new word dictionary
###########################################################
        
    def add_words_to_db(self,list_of_words  ):
        """
        insert words to the word table. if word exist, increment the frequency
        otherwise, insert a new word with frequency 1.
        
        Parameters:
            list_of_words: a list of strings
            
        Returns:
            new_words: a list of unique words updated/added 
            
        """ 
        word_freq = {x:list_of_words.count(x) for x in  list_of_words }   
         
        for (word,freq ) in word_freq.items():
            sql =  "SELECT wid FROM words WHERE word=%s" ; 
            self.cursor.execute(sql,word)
            wid = self.cursor.fetchone()
            if not wid: 
                sql = "INSERT INTO words (wid,word,part,frequency) SELECT \
                MAX(wid)+1,%s,%s,%s from words"
                self.cursor.execute(sql, ( word, '',freq) ) 
            else: 
                sql = "UPDATE words SET frequency = frequency+%s WHERE word=%s"
                self.cursor.execute(sql,[freq,word])
            self.mysql.commit() 
        return list(word_freq.keys())
    
    def read_words_from_db(self,list_of_words):
        """ get table entries of words in list_of_words """
         
        sql = "SELECT word,part,frequency FROM words WHERE word = %s;"
        result=[]
        for word in  list_of_words:
            self.cursor.execute(sql,word)
            result.append(  self,cursor.fetchone())
        return result; 
        
    
        
        