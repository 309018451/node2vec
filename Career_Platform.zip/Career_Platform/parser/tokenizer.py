#encoding=utf-8

from __future__ import print_function, unicode_literals

import jieba
import jieba.posseg as pseg
import re
from Career_Platform.parser.db_interface import DBInterface

class Tokenizer:
    def __init__(self):
        db_options = {'host':'localhost', 'user': 'root','password':'',
                 'port':3306,'database':'CAREER'}
    
        self.db = DBInterface(db_options) 
        
    def parse_strings(self,list_of_txt):
        pass
    
    
    def update_dict_db(self, list_mseg):
        """ add words in list_mseg to tokenizer and the word database
        -------------
        Parameters: 
            list_mseg: list of user segmented texts
        """
        # convert list of sentence to a list of list       
        list_mseg = [re.split(',| ',r) if (not isinstance(r,list)) \
                            else r for  r in  list_mseg ] 
        # flatten to a single list
        words = [ w for  sentence in list_mseg for w in sentence] 
        
        # add to database
        new_words = self.db.add_words_to_db(words) 
        
    
        #update tokenizer with new words
        for w in new_words: 
            self.add_user_word(w)  
        return list_mseg
    
            
    def update_tokenizer_db(self,list_uid,list_rid,list_mseg):
        """ add words in list_mseg to tokenizer and the word database
        -------------
        Parameters:
            list_uid: list of user ids
            list_rid: list of resume ids
            list_mseg: list of user segmented texts
        """
        # convert list of sentence to a list of list       
        list_mseg = self.update_dict_db(list_mseg)
        # put manual seg result in database
        for i in range(len(list_uid)):
            self.db.set_user_data_by_id(list_uid[i],list_rid[i],'mseg',
                                        ' '.join(list_mseg[i]))
        
        
      
class JiebaTokenizer(Tokenizer):
    """
    This class is used for Parsing
    Currently Using Jieba
    """
    def __init__(self): 
        Tokenizer.__init__(self)
        self.default_dict = "data/userdict.txt"
        jieba.enable_paddle()
        jieba.load_userdict(self.default_dict)
        
    def parse_strings(self,list_of_txt, simple=True):
        
        results = [] 

        for txt in list_of_txt: 
            
            words = pseg.cut(txt,use_paddle=False)
            if simple:
                words = [ w for w ,flag in words if w is not ' ']
            else:   
                words = [(w ,flag) for w ,flag in words if w is not ' ']
            
            results.append(words) 
        return results
 
    def add_user_word(self,word):
        print('adding',word,'..\n')
        jieba.add_word(word )
        
    def remove_user_word(self,word):
        jieba.del_word(word)
        
    def add_phrase(self,seg):
        print('adding',seg,'..\n')
        jieba.suggest_freq(seg,True)

 
