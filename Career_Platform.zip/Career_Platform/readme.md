Career Platform API
================

### Content

* `data/` : contains all demo data
    * `out_ori.txt` : original resume data dump 
    * `userdict.txt` : default user dictionary for jieba
    * `labels.txt` : list of all classification labels
* `parser/` : preprocessing and tokenizer classes
* `octree/` : octree classes
* `demo/` : test files

### Demo
To run the main demo:

	python demo/main.py
	
	
Run test files:

    python demo/test_classifier.py 
    
    python demo/test_octree.py 
    
    python demo/test_tokenizer.py 
    
### Deployment

Run the script file:

    chmod a+x deploy.sh
    ./deploy.sh <target_path>
    

This will create a directory called Career_Platform inside the target 
directory with the library files.  
e.g. to setup the front-end APP, run 

    ./deploy.sh <path/to/careerDataAnnotator>
    

### Database Usage
See `DB_HOWTO.md`
	
